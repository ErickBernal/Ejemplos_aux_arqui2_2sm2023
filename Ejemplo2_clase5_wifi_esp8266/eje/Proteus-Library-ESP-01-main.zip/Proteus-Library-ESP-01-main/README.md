# Proteus-Library-ESP-01
The ESP8266 module cannot be imported directly in Protues. So we will set up the full module by importing part of ESP8266 module inside proteus.
Full Video Link https://youtu.be/IIFt-_T1mpU
